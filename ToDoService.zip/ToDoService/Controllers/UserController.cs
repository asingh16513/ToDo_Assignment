﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.User.Command.AuthenticateUser;
using Application.User.Command.RegisterUser;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ToDoService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : BaseController
    {
        [AllowAnonymous]
        [HttpPost]
        [Route("Login")]
        public async Task<ActionResult> Authenticate([FromBody]AuthenticateUserCommand command)
        {
            return Ok(await Mediator.Send(command));
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("RegisterUser")]
        public async Task<ActionResult> RegisterUser([FromBody]RegisterUserCommand command)
        {
            return Ok(await Mediator.Send(command));
        }
    }
}