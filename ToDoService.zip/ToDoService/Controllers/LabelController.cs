﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Application.Helper;
using Application.Label.Command.AddLabel;
using Application.Label.Command.AssignItemLabel;
using Application.Label.Command.AssignLabelToList;
using Application.Label.Queries.DeleteLabelById;
using Application.Label.Queries.GetLabelById;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ToDoService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LabelController : BaseController
    {
        [HttpGet]
        [Route("GetLabels")]
        public async Task<ActionResult> GetLabels([FromQuery]EmptyQuery<List<Domain.Models.Label>> query)
        {
            return Ok(await Mediator.Send(query));
        }

        [HttpPost]
        [Route("AddLabel")]
        public async Task<ActionResult> AddLabel([FromBody]AddLabelCommand command)
        {
            return Ok(await Mediator.Send(command));
        }

        [HttpGet]
        [Route("GetLabelById")]
        public async Task<ActionResult> GetLabelById([FromQuery]GetLabelByIdQuery query)
        {
            return Ok(await Mediator.Send(query));
        }

        [HttpDelete]
        [Route("DeleteLabelById")]
        public async Task<ActionResult> DeleteLabelById([FromQuery]DeleteLabelByIdQuery query)
        {
            return Ok(await Mediator.Send(query));
        }

        [HttpPost]
        [Route("AssignLabelToItem")]
        public async Task<ActionResult> AssignLabelToItem([FromBody]AssignItemLabelCommand command)
        {
            return Ok(await Mediator.Send(command));
        }

        [HttpPost]
        [Route("AssignLabelToList")]
        public async Task<ActionResult> AssignLabelToList([FromBody]AssignLabelToListCommand command)
        {
            return Ok(await Mediator.Send(command));
        }
    }
}