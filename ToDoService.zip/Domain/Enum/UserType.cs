﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Enum
{
    public enum UserType
    {
        Admin,
        User
    } 
}
